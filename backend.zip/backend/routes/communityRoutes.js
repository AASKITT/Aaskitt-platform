const express = require('express');
const router = express.Router();
const CommunityMessage = require('../models/CommunityMessage');
const Group = require('../models/Group');
const Notification = require('../models/Notification');

// Helper: send push to many tokens — uses built-in https, no external dep needed
function sendPushToMany(tokens, title, body, data = {}) {
  if (!tokens || tokens.length === 0) return;
  const https = require('https');
  const payload = JSON.stringify(
    tokens.map(to => ({ to, sound: 'default', title, body, data }))
  );
  const options = {
    hostname: 'exp.host',
    path: '/--/api/v2/push/send',
    method: 'POST',
    headers: {
      'Accept': 'application/json',
      'Content-Type': 'application/json',
      'Content-Length': Buffer.byteLength(payload),
    },
  };
  const req = https.request(options, res => {
    res.on('data', () => {});
    res.on('end', () => {});
  });
  req.on('error', err => console.error('Push error:', err));
  req.write(payload);
  req.end();
}

// GET /api/community/:groupId  — fetch messages for a group
router.get('/:groupId', async (req, res) => {
  try {
    const group = await Group.findById(req.params.groupId);
    if (!group) return res.status(404).json({ error: 'Group not found' });

    const messages = await CommunityMessage.find({ groupId: req.params.groupId })
      .sort({ createdAt: -1 })
      .limit(100)
      .populate('replyTo');
    res.json(messages.reverse());
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Server error' });
  }
});

// POST /api/community/:groupId  — send a message
router.post('/:groupId', async (req, res) => {
  try {
    const { groupId } = req.params;
    const { anonymousId, nickname, text, image, tag, replyTo, location, latitude, longitude } = req.body;

    const group = await Group.findById(groupId);
    if (!group) return res.status(404).json({ error: 'Group not found' });

    // Check if banned
    if (group.bannedUsers.includes(anonymousId)) {
      return res.status(403).json({ error: 'You are banned from this group.' });
    }

    // Must be a member to send
    const isMember = group.members.some(m => m.anonymousId === anonymousId);
    if (!isMember) {
      return res.status(403).json({ error: 'Join the group first.' });
    }

    // Tag validation — required if group has tags defined
    if (group.tags && group.tags.length > 0) {
      if (!tag || !group.tags.includes(tag)) {
        return res.status(400).json({ error: 'Please select a tag to post.' });
      }
    }

    if (!text?.trim() && !image) {
      return res.status(400).json({ error: 'Message cannot be empty' });
    }

    let locationObj = null;
    if (latitude != null && longitude != null) {
      locationObj = { type: 'Point', coordinates: [Number(longitude), Number(latitude)] };
    } else if (location && Array.isArray(location.coordinates) && location.coordinates.length >= 2) {
      locationObj = { type: 'Point', coordinates: [Number(location.coordinates[0]), Number(location.coordinates[1])] };
    } else if (location && location.latitude != null && location.longitude != null) {
      locationObj = { type: 'Point', coordinates: [Number(location.longitude), Number(location.latitude)] };
    } else if (group.location && Array.isArray(group.location.coordinates) && group.location.coordinates.length >= 2) {
      locationObj = { type: 'Point', coordinates: [Number(group.location.coordinates[0]), Number(group.location.coordinates[1])] };
    }

    const newMessage = new CommunityMessage({
      anonymousId,
      nickname,
      text: text?.trim() || '',
      image: image || null,
      tag: tag || null,
      groupId,
      replyTo: replyTo || null,
      location: locationObj,
    });

    await newMessage.save();

    let populatedMessage = newMessage;
    if (replyTo) {
      populatedMessage = await CommunityMessage.findById(newMessage._id).populate('replyTo');
    }

    // Emit socket event to all clients
    req.io.emit('newCommunityMessage', { ...populatedMessage.toObject(), groupId });

    // ── NOTIFICATIONS FOR JOINED GROUP MEMBERS ONLY ────────────────────────────
    const msgBody = text?.trim()
      ? `${nickname}: ${text.trim().substring(0, 80)}`
      : `${nickname} sent an image`;

    // 1. Filter ONLY members who have JOINED this group (except sender)
    const joinedMembers = group.members.filter(m => m.anonymousId !== anonymousId);

    // Push notification tokens for joined members
    const joinedMemberTokens = joinedMembers
      .filter(m => m.expoPushToken)
      .map(m => m.expoPushToken);

    if (joinedMemberTokens.length > 0) {
      sendPushToMany(
        joinedMemberTokens,
        group.name,
        msgBody,
        { groupId: groupId.toString(), msgId: newMessage._id.toString() }
      );
    }

    // 2. Save in-app notification for joined members ONLY
    await Promise.all(
      joinedMembers.map(async (m) => {
        try {
          const notif = new Notification({
            recipientId: m.anonymousId,
            senderNickname: nickname,
            type: 'post_created',
            groupId: groupId.toString(),
            postId: newMessage._id,
            text: text?.trim() || 'sent an image',
          });
          await notif.save();
          req.io.to(`user_${m.anonymousId}`).emit('newNotification', notif);
        } catch (e) {}
      })
    );

    // Socket live event to joined members
    joinedMembers.forEach(m => {
      req.io.to(`user_${m.anonymousId}`).emit('communityNewMsg', {
        groupId, groupName: group.name, senderNickname: nickname, text: text?.trim() || ''
      });
    });
    // ──────────────────────────────────────────────────────────────────────────

    res.status(201).json(populatedMessage);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Server error' });
  }
});

// DELETE /api/community/:groupId/messages/:msgId — author or mod deletes a message
router.delete('/:groupId/messages/:msgId', async (req, res) => {
  try {
    const { groupId, msgId } = req.params;
    const requesterId = req.body.requesterId || req.body.anonymousId;

    const msg = await CommunityMessage.findById(msgId);
    if (!msg) return res.status(404).json({ error: 'Message not found' });

    let canDelete = false;
    if (msg.anonymousId === requesterId || requesterId === 'team_aaskitt') {
      canDelete = true;
    } else if (groupId !== 'main') {
      const group = await Group.findById(groupId);
      if (group && group.creatorId === requesterId) {
        canDelete = true;
      }
    }

    if (!canDelete) {
      return res.status(403).json({ error: 'Not authorized to delete this message' });
    }

    await CommunityMessage.findByIdAndDelete(msgId);
    if (req.io) {
      req.io.emit('communityMessageDeleted', { groupId, msgId });
    }
    res.json({ success: true, msgId });
  } catch (err) {
    console.error('Delete message error:', err);
    res.status(500).json({ error: 'Server error' });
  }
});

// POST & PUT /api/community/:groupId/messages/:msgId/view — increment view count
const incrementCommunityMessageView = async (req, res) => {
  try {
    const { groupId, msgId } = req.params;
    const msg = await CommunityMessage.findByIdAndUpdate(
      msgId,
      { $inc: { views: 1 } },
      { returnDocument: 'after', new: true }
    );
    if (msg && req.io) {
      req.io.emit('communityMessageViewed', { groupId, msgId, views: msg.views });
    }
    res.json({ views: msg?.views || 0 });
  } catch (err) {
    res.status(500).json({ error: 'Server error' });
  }
};
router.post('/:groupId/messages/:msgId/view', incrementCommunityMessageView);
router.put('/:groupId/messages/:msgId/view', incrementCommunityMessageView);

module.exports = router;
